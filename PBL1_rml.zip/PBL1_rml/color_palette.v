module color_palette (
    input  wire        clk,
    input  wire        we,
    input  wire [7:0]  wr_addr,
    input  wire [23:0] wr_data,
    input  wire [7:0]  rd_addr,
    output reg  [23:0] rgb_out
);

    reg [23:0] clut_ram [0:255];

    initial begin
        clut_ram[8'h00] = 24'h000000; // Transparente / Vazio
        clut_ram[8'h01] = 24'hF0EAD6; // Bege / Creme Claro (Casa Clara)
        clut_ram[8'h02] = 24'h4A3728; // Castanho / Marrom Tabuleiro (Casa Escura)
		  clut_ram[8'h03] = 24'hFFFFFF; // Branco (Borda/Detalhe do Sprite)
        clut_ram[8'h04] = 24'h00E5FF; // Azul Ciano Vivo (Preenchimento do Sprite)
        clut_ram[8'hFF] = 24'hFF1010; // Vermelho Intenso para o Triangulo
    end

    always @(posedge clk) begin
        if (we)
            clut_ram[wr_addr] <= wr_data;
        rgb_out <= clut_ram[rd_addr];
    end

endmodule