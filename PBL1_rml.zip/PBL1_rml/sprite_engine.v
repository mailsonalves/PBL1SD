module sprite_engine (
    input  wire        clk,
    input  wire        rst_n,

    // Coordenadas lógicas do feixe VGA atual (320x240)
    input  wire [8:0]  pixel_x,
    input  wire [7:0]  pixel_y,

    // Interface de escrita da Tabela de Atributos dos Sprites (SAT)
    input  wire        sat_we,
    input  wire [4:0]  sat_addr,      // 32 Sprites (0 a 31)
    input  wire [31:0] sat_data,      // Dados do atributo

    output reg  [7:0]  sp_pixel_color_idx
);

    // =========================================================================
    // 1. Tabela de Atributos dos Sprites (Sprite Attribute Table - SAT)
    // [31]    : enable
    // [30]    : flip_x
    // [29]    : flip_y
    // [28:25] : reservado
    // [24:16] : pos_x (9 bits - 0 a 319)
    // [15:8]  : pos_y (8 bits - 0 a 239)
    // [7:0]   : pattern_base_id (ID do tile 8x8)
    // =========================================================================
    reg [31:0] sat_ram [0:31];
    integer k;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // Limpa todos os sprites no reset
            for (k = 0; k < 32; k = k + 1) begin
                sat_ram[k] <= 32'd0;
            end
            
            // Ativa o Sprite 0 para demonstração (Deslocado para X=40, Y=40)
            // {enable(1), flip_x(1), flip_y(1), res(4), x(9), y(8), id(8)}
            sat_ram[0] <= {1'b1, 1'b0, 1'b0, 4'd0, 9'd40, 8'd40, 8'd3};
            
            // Ativa um segundo Sprite bem no meio do triângulo para testar a sobreposição!
            sat_ram[1] <= {1'b1, 1'b0, 1'b0, 4'd0, 9'd160, 8'd120, 8'd3};
            
        end else if (sat_we) begin
            sat_ram[sat_addr] <= sat_data;
        end
    end

    // =========================================================================
    // 2. Avaliação de Sobreposição e Seleção do Sprite Visível
    // =========================================================================
    wire [7:0] sprite_colors [0:31];
    wire       sprite_active_pixel [0:31];

    genvar i;
    generate
        for (i = 0; i < 32; i = i + 1) begin : gen_sprites
            wire [31:0] attr = sat_ram[i];
            
            wire enable      = attr[31];
            wire flip_x      = attr[30];
            wire flip_y      = attr[29];
            wire [8:0] sp_x  = attr[24:16];
            wire [7:0] sp_y  = attr[15:8];
            wire [7:0] base_id = attr[7:0];

            // Verificação se o feixe está dentro da caixa 16x16 do sprite
            wire inside_x = (pixel_x >= sp_x) && (pixel_x < sp_x + 9'd16);
            wire inside_y = (pixel_y >= sp_y) && (pixel_y < sp_y + 8'd16);
            wire hit      = enable && inside_x && inside_y;

            // Coordenadas relativas dentro do sprite 16x16 (0 a 15)
            wire [3:0] rel_x = pixel_x[3:0] - sp_x[3:0];
            wire [3:0] rel_y = pixel_y[3:0] - sp_y[3:0];

            // Aplicação de Espelhamento (Flip)
            wire [3:0] eff_x = flip_x ? (4'd15 - rel_x) : rel_x;
            wire [3:0] eff_y = flip_y ? (4'd15 - rel_y) : rel_y;

            // Quadrante: Top-Left (0), Top-Right (1), Bottom-Left (2), Bottom-Right (3)
            wire [1:0] quadrant = {eff_y[3], eff_x[3]};
            wire [7:0] tile_offset = {6'd0, quadrant};
            wire [7:0] current_tile = base_id + tile_offset;

            wire [2:0] sub_px = eff_x[2:0];
            wire [2:0] sub_py = eff_y[2:0];

            // Padrão de demonstração: Quadrado com borda e cor interna index 2 (marrom)
            wire border = (sub_px == 0 || sub_px == 7 || sub_py == 0 || sub_py == 7);
            
            assign sprite_colors[i] = hit ? (border ? 8'hFF : 8'h02) : 8'h00;
            assign sprite_active_pixel[i] = hit && (sprite_colors[i] != 8'h00);
        end
    endgenerate

    // =========================================================================
    // 3. Resolução de Prioridade (Sprite 0 tem maior prioridade)
    // =========================================================================
    integer j;
    always @(*) begin
        sp_pixel_color_idx = 8'h00;
        for (j = 31; j >= 0; j = j - 1) begin
            if (sprite_active_pixel[j])
                sp_pixel_color_idx = sprite_colors[j];
        end
    end

endmodule