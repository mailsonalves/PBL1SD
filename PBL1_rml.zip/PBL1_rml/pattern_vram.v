module pattern_vram (
    input  wire        clk,
    input  wire        we,
    input  wire [13:0] addr,
    input  wire [7:0]  data_in,
    output reg  [7:0]  data_out
);

    (* ramstyle = "M10K, no_rw_check" *) reg [7:0] ram [0:16383];

    wire [7:0] tile_id = addr[13:6];

    always @(posedge clk) begin
        if (we) begin
            ram[addr] <= data_in;
            data_out  <= data_in;
        end else begin
            case (tile_id)
                8'h01: data_out <= 8'h01; // Cor solida para a Casa Clara
                8'h02: data_out <= 8'h02; // Cor solida para a Casa Escura
                default: data_out <= ram[addr];
            endcase
        end
    end

endmodule