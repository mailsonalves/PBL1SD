module pattern_vram (
    input  wire        clk,
    input  wire        we,
    input  wire [13:0] addr,
    input  wire [7:0]  data_in,
    output reg  [7:0]  data_out
);

    (* ramstyle = "M10K, no_rw_check" *) reg [7:0] ram [0:16383];
    
    reg [7:0] ram_q;
    reg [7:0] tile_id_delay; // Guarda o ID para o próximo ciclo
    wire [7:0] tile_id = addr[13:6];

    // Inferência pura de bloco de memória RAM M10K
    always @(posedge clk) begin
        if (we) begin
            ram[addr] <= data_in;
        end
        ram_q <= ram[addr];
        tile_id_delay <= tile_id; // Sincroniza com a leitura da RAM
    end

    // Multiplexador Combinacional Externo
    always @(*) begin
        case (tile_id_delay)
            8'h01: data_out = 8'h01; // Cor solida para a Casa Clara
            8'h02: data_out = 8'h02; // Cor solida para a Casa Escura
            default: data_out = ram_q;
        endcase
    end
endmodule