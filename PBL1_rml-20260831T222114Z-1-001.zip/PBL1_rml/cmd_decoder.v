// ============================================================================
// cmd_decoder.v (Trecho atualizado para Pontos 1, 2 e 3)
// ============================================================================
module cmd_decoder (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [31:0] cmd_data,
    input  wire        cmd_valid,

    // Interface com SAT (sprite_engine)
    output reg         sat_we_pos,
    output reg         sat_we_attr,
    output reg  [4:0]  sat_addr,
    output reg  [8:0]  out_x,
    output reg  [7:0]  out_y,
    output reg  [7:0]  out_tile_id,
    output reg         out_enable,
    output reg         out_flip_h,
    output reg         out_flip_v,
    output reg         out_priority,
    output reg  [1:0]  out_palette_bank
);

    localparam OP_UPDATE_SPRITE_POS = 4'h6;
    localparam OP_SET_SPRITE_ATTR   = 4'hB;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sat_we_pos       <= 1'b0;
            sat_we_attr      <= 1'b0;
            sat_addr         <= 5'd0;
            out_x            <= 9'd0;
            out_y            <= 8'd0;
            out_tile_id      <= 8'd0;
            out_enable       <= 1'b0;
            out_flip_h       <= 1'b0;
            out_flip_v       <= 1'b0;
            out_priority     <= 1'b0;
            out_palette_bank <= 2'b00;
        end else begin
            sat_we_pos  <= 1'b0;
            sat_we_attr <= 1'b0;

            if (cmd_valid) begin
                case (cmd_data[31:28])
                    OP_UPDATE_SPRITE_POS: begin
                        sat_we_pos <= 1'b1;
                        sat_addr   <= cmd_data[27:23];
                        out_x      <= cmd_data[22:14];
                        out_y      <= cmd_data[13:6];
                    end

                    OP_SET_SPRITE_ATTR: begin
                        sat_we_attr      <= 1'b1;
                        sat_addr         <= cmd_data[27:23];
                        out_tile_id      <= cmd_data[22:15];
                        out_palette_bank <= cmd_data[14:13];
                        out_priority     <= cmd_data[12];
                        out_enable       <= cmd_data[11];
                        out_flip_h       <= cmd_data[10];
                        out_flip_v       <= cmd_data[9];
                    end
                endcase
            end
        end
    end

endmodule