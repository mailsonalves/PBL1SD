module gpu_de1_soc_top (
    input  wire        CLOCK_50,
    input  wire [3:0]  KEY,
    input  wire [9:0]  SW,
    output wire [9:0]  LEDR,

    // Conexoes VGA DE1-SoC
    output wire        VGA_HS,
    output wire        VGA_VS,
    output wire [7:0]  VGA_R,
    output wire [7:0]  VGA_G,
    output wire [7:0]  VGA_B,
    output wire        VGA_BLANK_N,
    output wire        VGA_SYNC_N,
    output wire        VGA_CLK
);

    wire rst_n = KEY[0];

    // 1. Clock Pixel 25 MHz
    reg clk_25m;
    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) clk_25m <= 1'b0;
        else clk_25m <= ~clk_25m;
    end

    assign VGA_CLK    = clk_25m;
    assign VGA_SYNC_N = 1'b0;

    // 2. Gerador VGA
    wire video_active;
    wire [8:0] pixel_x;
    wire [7:0] pixel_y;

    vga_sync u_vga_sync (
        .clk_25m     (clk_25m),
        .rst_n       (rst_n),
        .hsync       (VGA_HS),
        .vsync       (VGA_VS),
        .video_active(video_active),
        .pixel_x     (pixel_x),
        .pixel_y     (pixel_y)
    );

    assign VGA_BLANK_N = video_active;

    // 3. Controlador de Entradas
    wire [31:0] cmd_data;
    wire        cmd_valid;
    wire        cmd_ready;

    board_input_controller u_input_ctrl (
        .clk      (CLOCK_50),
        .rst_n    (rst_n),
        .SW       (SW),
        .KEY      (KEY[3:1]),
        .cmd_ready(cmd_ready),
        .cmd_data (cmd_data),
        .cmd_valid(cmd_valid)
    );

    // 4. Decodificador de Instrucoes
    wire        pal_we;
    wire [7:0]  pal_addr;
    wire [23:0] pal_data;
    wire        tm_we;
    wire [5:0]  tm_x;
    wire [4:0]  tm_y;
    wire [7:0]  tm_tile_id;
    wire [8:0]  scroll_x;
    wire [7:0]  scroll_y;
    wire        sat_we;
    wire [4:0]  sat_addr;
    wire [31:0] sat_data;
    wire [8:0]  rast_x0, rast_x1, rast_x2;
    wire [7:0]  rast_y0, rast_y1, rast_y2;
    wire [7:0]  rast_color;
    wire        rast_clear_screen;
    wire        rast_start;
    wire        rast_busy;

    cmd_decoder u_cmd_decoder (
    .clk              (clk_25m),
    .rst_n            (rst_n),
    .cmd_data         (cmd_data),      // Barramento de 32 bits
    .cmd_valid        (cmd_valid),     // Pulso de comando válido

    // Interface com Sprite Engine
    .sat_we_pos       (sat_we_pos),
    .sat_we_attr      (sat_we_attr),
    .sat_addr         (sat_addr),
    .out_x            (sat_in_x),
    .out_y            (sat_in_y),
    .out_tile_id      (sat_in_tile_id),
    .out_enable       (sat_in_enable),
    .out_flip_h       (sat_in_flip_h),
    .out_flip_v       (sat_in_flip_v),
    .out_priority     (sat_in_priority),
    .out_palette_bank (sat_in_palette_bank)
);

    // 5. Motor de Background
    wire [13:0] bg_vram_addr;

    bg_engine u_bg_engine (
        .clk               (CLOCK_50),
        .pixel_x           (pixel_x),
        .pixel_y           (pixel_y),
        .scroll_x          (scroll_x),
        .scroll_y          (scroll_y),
        .we                (tm_we),
        .wr_x              (tm_x),
        .wr_y              (tm_y),
        .wr_tile_id        (tm_tile_id),
        .bg_vram_addr      (bg_vram_addr)
    );

    // 5.1 Motor de Sprites
    wire [13:0] sp_vram_addr;

    sprite_engine u_sprite_engine (
    .clk                 (clk_25m),
    .rst_n               (rst_n),
    .pixel_x             (pixel_x),
    .pixel_y             (pixel_y),

    // Escrita via cmd_decoder
    .sat_we_pos          (sat_we_pos),
    .sat_we_attr         (sat_we_attr),
    .sat_addr            (sat_addr),
    .in_x                (sat_in_x),
    .in_y                (sat_in_y),
    .in_tile_id          (sat_in_tile_id),
    .in_enable           (sat_in_enable),
    .in_flip_h           (sat_in_flip_h),
    .in_flip_v           (sat_in_flip_v),
    .in_priority         (sat_in_priority),
    .in_palette_bank     (sat_in_palette_bank),

    // VRAM e Saídas
    .pattern_addr        (pattern_addr),
    .pattern_data        (pattern_data),
    .sprite_pixel_idx    (sprite_pixel),
    .sprite_priority     (sprite_priority),
    .sprite_palette_bank (sprite_palette_bank),
    .sprite_hit          (sprite_hit)
);

    // 5.2 VRAM Dual-Port
    wire [7:0] bg_pixel;
    wire [7:0] sp_pixel;

    pattern_vram u_patterns (
        .clk        (CLOCK_50),
        .we_a       (1'b0),
        .addr_a     (bg_vram_addr),
        .data_in_a  (8'd0),
        .data_out_a (bg_pixel),
        .addr_b     (sp_vram_addr),
        .data_out_b (sp_pixel)
    );

    // 6. Rasterizador e Framebuffer
    wire        buf_we;
    wire [16:0] buf_wr_addr;
    wire [7:0]  buf_wr_data;
    wire [7:0]  poly_pixel;

    polygon_rasterizer u_rasterizer (
    .clk                 (clk_25m),
    .rst_n               (rst_n),
    .start_rect          (start_rect),
    .rect_x1             (rect_x1),
    .rect_y1             (rect_y1),
    .rect_x2             (rect_x2),
    .rect_y2             (rect_y2),
    .color_idx           (poly_color_idx),
    .busy                (rast_busy),
    .fb_we               (fb_we),
    .fb_x                (fb_x),
    .fb_y                (fb_y),
    .fb_color            (fb_color)
);

    wire [16:0] buf_rd_addr = {pixel_y, 8'd0} + {pixel_y, 6'd0} + pixel_x;

    polygon_buffer u_poly_buffer (
        .clk_wr  (CLOCK_50),
        .we      (buf_we),
        .addr_wr (buf_wr_addr),
        .data_in (buf_wr_data),
        .clk_rd  (clk_25m),
        .addr_rd (buf_rd_addr),
        .data_out(poly_pixel)
    );

    // 7. Compositor
    wire [7:0] final_pixel_idx;

    compositor u_compositor (
    .sprite_hit          (sprite_hit),
    .sprite_pixel        (sprite_pixel),
    .sprite_priority     (sprite_priority),
    .poly_pixel          (poly_pixel),
    .bg_pixel            (bg_pixel),
    .final_pixel_idx     (final_pixel_idx)
);

    // 8. Paleta de Cores e Saida VGA
    wire [23:0] rgb_24;

    color_palette u_palette (
        .clk    (CLOCK_50),
        .we     (pal_we),
        .wr_addr(pal_addr),
        .wr_data(pal_data),
        .rd_addr(final_pixel_idx),
        .rgb_out(rgb_24)
    );

    assign VGA_R = video_active ? rgb_24[23:16] : 8'd0;
    assign VGA_G = video_active ? rgb_24[15:8]  : 8'd0;
    assign VGA_B = video_active ? rgb_24[7:0]   : 8'd0;

    assign LEDR[0] = rast_busy;
    assign LEDR[1] = cmd_valid;
    assign LEDR[2] = SW[0];
    assign LEDR[9] = rst_n;

endmodule