// ============================================================================
// compositor.v (Composição de Camadas com Suporte à Prioridade do Sprite)
// ============================================================================
module compositor (
    input  wire        sprite_hit,
    input  wire [7:0]  sprite_pixel,
    input  wire        sprite_priority,
    
    input  wire [7:0]  poly_pixel,
    input  wire [7:0]  bg_pixel,
    
    output reg  [7:0]  final_pixel_idx
);

    always @(*) begin
        // Regra de Transparência: Índice 0x00 é considerado transparente em qualquer camada
        
        if (sprite_hit && sprite_priority) begin
            // Sprite com Prioridade Alta (à frente de polígonos e background)
            final_pixel_idx = sprite_pixel;
        end else if (poly_pixel != 8'h00) begin
            // Camada de Polígonos
            final_pixel_idx = poly_pixel;
        end else if (bg_pixel != 8'h00) begin
            // Camada de Background
            final_pixel_idx = bg_pixel;
        end else if (sprite_hit) begin
            // Sprite com Prioridade Baixa (atrás do BG/Polígonos quando não forem transparentes)
            final_pixel_idx = sprite_pixel;
        end else begin
            // Cor de Fundo / Backdrop
            final_pixel_idx = 8'h00;
        end
    end

endmodule