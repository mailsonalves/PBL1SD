// ============================================================================
// polygon_rasterizer.v (Suporte a Triângulos e Retângulos Dedicados)
// ============================================================================
module polygon_rasterizer (
    input  wire        clk,
    input  wire        rst_n,
    
    // Interface de Comando
    input  wire        start_rect,
    input  wire [8:0]  rect_x1,
    input  wire [7:0]  rect_y1,
    input  wire [8:0]  rect_x2,
    input  wire [7:0]  rect_y2,
    input  wire [7:0]  color_idx,
    
    output reg         busy,
    
    // Interface com Framebuffer / Polygon Buffer
    output reg         fb_we,
    output reg  [8:0]  fb_x,
    output reg  [7:0]  fb_y,
    output reg  [7:0]  fb_color
);

    // Estados da FSM
    localparam IDLE       = 2'b00;
    localparam RASTER_RECT = 2'b01;

    reg [1:0] state;
    
    // Limites ordenados do Retângulo
    reg [8:0] x_min, x_max, curr_x;
    reg [7:0] y_min, y_max, curr_y;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state    <= IDLE;
            busy     <= 1'b0;
            fb_we    <= 1'b0;
            fb_x     <= 9'd0;
            fb_y     <= 8'd0;
            fb_color <= 8'd0;
            curr_x   <= 9'd0;
            curr_y   <= 8'd0;
        end else begin
            fb_we <= 1'b0;

            case (state)
                IDLE: begin
                    if (start_rect) begin
                        busy     <= 1'b1;
                        fb_color <= color_idx;
                        
                        // Ordenação automática de min/max para garantir suporte a coordenadas invertidas
                        x_min  <= (rect_x1 < rect_x2) ? rect_x1 : rect_x2;
                        x_max  <= (rect_x1 < rect_x2) ? rect_x2 : rect_x1;
                        y_min  <= (rect_y1 < rect_y2) ? rect_y1 : rect_y2;
                        y_max  <= (rect_y1 < rect_y2) ? rect_y2 : rect_y1;
                        
                        curr_x <= (rect_x1 < rect_x2) ? rect_x1 : rect_x2;
                        curr_y <= (rect_y1 < rect_y2) ? rect_y1 : rect_y2;
                        
                        state  <= RASTER_RECT;
                    end
                end

                RASTER_RECT: begin
                    // Escreve o pixel atual no framebuffer
                    fb_we <= 1'b1;
                    fb_x  <= curr_x;
                    fb_y  <= curr_y;

                    // Avanço do cursor de rasterização
                    if (curr_x < x_max) begin
                        curr_x <= curr_x + 1'b1;
                    end else begin
                        curr_x <= x_min;
                        if (curr_y < y_max) begin
                            curr_y <= curr_y + 1'b1;
                        end else begin
                            // Fim da área do retângulo
                            state <= IDLE;
                            busy  <= 1'b0;
                        end
                    end
                end
            endcase
        end
    end

endmodule